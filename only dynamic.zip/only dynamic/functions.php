<?php

/**
 * Proper way to enqueue scripts and styles.
 */
function wpdocs_theme_name_scripts() {
	wp_enqueue_style( 'style-name', get_stylesheet_uri() );
	wp_enqueue_style( 'style-name-2',  get_template_directory_uri() . '/assets/css/bootstrap.min.css' );
	
	 wp_enqueue_script( 'script-name', get_template_directory_uri() . '/assets/js/bootstrap.bundle.min.js', array(), '1.0.0', true );
}
add_action( 'wp_enqueue_scripts', 'wpdocs_theme_name_scripts' );


add_theme_support( 'title-tag' );
add_theme_support( 'custom-logo', array(
    'height' => 480,
    'width'  => 720,
) );

add_theme_support( 'post-thumbnails' );
add_theme_support( 'post-thumbnails', array( 'post' ) );          // Posts only
add_theme_support( 'post-thumbnails', array( 'page' ) );          // Pages only
add_theme_support( 'post-thumbnails', array( 'post', 'movie' ) ); // Posts and Movies

register_sidebar( array(
    'name'           =>'Top Right BD Logo',
		'id'             => "bdlogo",
		'description'    => '',
		'class'          => '',
		'before_widget'  => '',
		'after_widget'   => "",
) );
register_sidebar( array(
    'name'           =>'Hero Title',
		'id'             => "herotitle",
		'description'    => '',
		'class'          => '',
		'before_widget'  => '',
		'after_widget'   => "",
) );
if ( ! function_exists( 'mytheme_register_nav_menu' ) ) {

	function mytheme_register_nav_menu(){
		register_nav_menus( array(
	    	'primary_menu' => __( 'Primary Menu', 'text_domain' ),
	    	'footer_menu'  => __( 'Footer Menu', 'text_domain' ),
		) );
	}
	add_action( 'after_setup_theme', 'mytheme_register_nav_menu', 0 );
}
register_sidebar( array(
    'name'           =>'Hero Card 1',
		'id'             => "cardimg1",
		'description'    => '',
		'class'          => '',
		'before_widget'  => '',
		'after_widget'   => "",
) );
register_sidebar( array(
    'name'           =>'Hero Card 2',
		'id'             => "cardimg2",
		'description'    => '',
		'class'          => '',
		'before_widget'  => '',
		'after_widget'   => "",
) );
register_sidebar( array(
    'name'           =>'Hero Card 3',
		'id'             => "cardimg3",
		'description'    => '',
		'class'          => '',
		'before_widget'  => '',
		'after_widget'   => "",
) );
register_sidebar( array(
    'name'           =>'Hero Body 1',
		'id'             => "cardbody1",
		'description'    => '',
		'class'          => '',
		'before_widget'  => '',
		'after_widget'   => "",
) );
register_sidebar( array(
    'name'           =>'photo Image Left',
		'id'             => 'photoimg1',
		'description'    => '',
		'class'          => '',
		'before_widget'  => '',
		'after_widget'   => "",
) );
register_sidebar( array(
    'name'           =>'photo Image Right',
		'id'             => 'phototimg2',
		'description'    => '',
		'class'          => '',
		'before_widget'  => '',
		'after_widget'   => "",
) );
register_sidebar( array(
    'name'           =>'photo Title',
		'id'             => 'phototitle',
		'description'    => '',
		'class'          => '',
		'before_widget'  => '',
		'after_widget'   => "",
) );
register_sidebar( array(
    'name'           =>'photo Bottom Image 1',
		'id'             => 'photobottomimg1',
		'description'    => '',
		'class'          => '',
		'before_widget'  => '',
		'after_widget'   => "",
) );
register_sidebar( array(
    'name'           =>'photo Bottom Body 2',
		'id'             => 'photobottomimg2',
		'description'    => '',
		'class'          => '',
		'before_widget'  => '',
		'after_widget'   => "",
) );
register_sidebar( array(
    'name'           =>'photo Bottom Body 3',
		'id'             => 'photobottomimg3',
		'description'    => '',
		'class'          => '',
		'before_widget'  => '',
		'after_widget'   => "",
) );
register_sidebar( array(
    'name'           =>'photo Bottom Body 4',
		'id'             => 'photobottomimg4',
		'description'    => '',
		'class'          => '',
		'before_widget'  => '',
		'after_widget'   => "",
) );

add_theme_support( 'post-thumbnails' );
add_theme_support( 'post-thumbnails', array( 'post' ) );          // Posts only
add_theme_support( 'post-thumbnails', array( 'page' ) );          // Pages only
add_theme_support( 'post-thumbnails', array( 'post', 'movie' ) ); // Posts and Movies

register_sidebar( array(
    'name'           =>'footer_left',
		'id'             => 'footerleft',
		'description'    => '',
		'class'          => '',
		'before_widget'  => '',
		'after_widget'   => "",
) );
register_sidebar( array(
    'name'           =>'footer_right',
		'id'             => 'footerright',
		'description'    => '',
		'class'          => '',
		'before_widget'  => '',
		'after_widget'   => "",
) );