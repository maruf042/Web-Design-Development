<?php 
/**
 * Template Name: about
 */


get_header();?>
    <!-- search option part start -->
    <section class="container search">
      <div class="row">
        <div class="col-sm-8"></div>
        <div class="col-sm-4">
          <form action="">
            <input type="text" value="<?=get_search_query();?>"name="s">
            <button>Search</button>
          </form>
        </div>
      </div>
    </section>
    <!-- search option part end -->
    <!-- marque part start -->
       <section class="container">
        <marquee behavior="" direction="">
          <?php dynamic_sidebar('mark');?>
        </marquee>
       </section>



    <!-- marque part end -->
    <!-- hero part start -->
        <section class="container hero text-center">
          <div class="row hero_top">
            <?php dynamic_sidebar('herotitle');?>
          </div>
            <div class="row hero_bottom">
            <div class="col-sm-4">
            <div class="card" style="width: 18rem;">
                <?php dynamic_sidebar('cardimg1');?>
            <!-- <img src="..." class="card-img-top" alt="..."> -->
                <div class="card-body">
                  <?php dynamic_sidebar('cardbody1');?>
    
            </div>
          </div>
          </div>
            </div>
            <div class="col-sm-4">
            <div class="card" style="width: 18rem;">
                <?php dynamic_sidebar('cardimg1');?>
            <!-- <img src="..." class="card-img-top" alt="..."> -->
                <div class="card-body">
                  <?php dynamic_sidebar('cardbody1');?>
    
            </div>
          </div>
          </div>
            <div class="col-sm-4">3</div>
          </div>
        </section>


     
           

    <!-- hero part end -->

    <!-- photo part start -->
    <section class="container photo text-center mt-5 mb-5">
      <div class="row">
        <div class="col-sm-5">
          <?php dynamic_sidebar('photoimg1');?>
        </div>
        <div class="col-sm-2">
        <?php dynamic_sidebar('phototitle');?>
        </div>
        <div class="col-sm-5">
        <?php dynamic_sidebar('phototimg2');?>
        </div>
      </div>
        
      <div class="row">
        <div class="col-sm-3">
        <div class="card" style="width: 18rem;">
        <?php dynamic_sidebar('photobottomimg1');?>
     </div>
        </div>
        <div class="col-sm-3">
        <div class="card" style="width: 18rem;">
        <?php dynamic_sidebar('photobottomimg2');?>
     </div>
        </div>
        <div class="col-sm-3">
          <div class="card" style="width: 18rem;">
        <?php dynamic_sidebar('photobottomimg3');?>
     </div>
    </div>
        <div class="col-sm-3">
        <div class="card" style="width: 18rem;">
        <?php dynamic_sidebar('photobottomimg4');?>
     </div>
        </div>
      </div>
    </section>
    <!-- photo part end -->
    <scetion class="container  photo text-center mt-5 mb-5">
    <div class="row">
        <div class="col-sm-5">
          <?php dynamic_sidebar('photoimg1');?>
        </div>
        <div class="col-sm-2">
        <?php dynamic_sidebar('phototitle');?>
        </div>
        <div class="col-sm-5">
        <?php dynamic_sidebar('phototimg2');?>
        </div>
      </div>
    </scetion>


    <section class="container">
    <?php
        $qry1 = new WP_Query([
            'post_type'=>'post',
            'category_name'=>'padma'
        ]);
        ?>
      <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <?php
    $x=0;
     while($qry1->have_posts()){$qry1->the_post();
    $x++;
    ?>
    <div class="carousel-item <?= ($x==1)?'active':''?>">
        <?php the_title();?>
      <!-- <img src="..." class="d-block w-100" alt="..."> -->
    </div>
     <?php }?>
    <!-- <div class="carousel-item">
      <img src="..." class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="..." class="d-block w-100" alt="...">
    </div> -->
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
    </section>
    <?php get_footer();?>

   

<?php wp_footer();?>
</body>
</html>